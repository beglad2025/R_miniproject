# 1. 데이터 준비

library(foreign) # SPSS 파일 로드
library(dplyr) # 전처리
library(ggplot2) # 시각화
library(readxl) # 엑셀 파일 불러오기
library(Amelia)

# 데이터 불러오기

raw_welfare <- read.spss(file = "Koweps_hpc10_2015_beta1.sav",
                         to.data.frame = T)
head(raw_welfare)
str(raw_welfare)

# 필요한 자료만 넣은 복사본 만들기

welfare <- raw_welfare[c("h10_g3","h10_g4","h10_g10",
                         "h10_g11","h10_eco9","p1002_8aq1",
                         "h10_reg7")]
str(welfare)


# 2. 데이터 검토

# 1) 변수명 변경

colnames(welfare) <- c("gender","birth.year","marriage",
                       "religion", "jobcode","month.wage",
                       "area")
str(welfare)

# 2) 데이터 전처리

missmap(welfare, col = c('red','grey'))
# month.wage와 jobcode에만 결측값 있음을 확인


# birth.year를 기반으로 파생변수 age와 age.cut 생성

welfare$age <- 2021 - welfare$birth.year + 1
welfare$age

welfare$age.cut <- cut(welfare$age,
                       breaks = c(0,10,20,30,40,50,60,70,max(welfare$age)+1),
                       right = F)
table(welfare$age.cut)
# [0,10)  [10,20)  [20,30)  [30,40)  [40,50)  [50,60)  [60,70) [70,116) 
# 148     1520     1850     1333     2058     2194     2055     5506 


# 이상치 인식

boxplot(welfare$age)  #outlier은 없음

summary(welfare$age)  #Min 8, Max 115 : 이상치 있음


# 이상치 처리 : 극단값 절단 방법
# 정상범위를 17~99로 설정
# 취업(아르바이트)가능 최저 연령이 만 15세인 점을 감안하여 설정

sum(welfare$age<=16 | welfare$age>=100)  #1238
sum(welfare$age<100 & welfare$age>70) # 5227

welfare <- welfare %>% 
             filter(welfare$age>=17 & welfare$age<=99)

welfare$age.cut <- cut(welfare$age,
                       breaks = c(10,20,30,40,50,60,70,80,max(welfare$age)+1),
                       right = F)
table(welfare$age.cut)
# [10,20)  [20,30)  [30,40)  [40,50)  [50,60)  [60,70)  [70,80) [80,100) 
# 485     1850     1333     2058     2194     2055     2176     3275 

hist(welfare$age)
dev.off()


# 결측값 처리(month.wage, job)

sum(is.na(welfare$jobcode)) #7900

sum(is.na(welfare$month.wage)) #10792

no.na.welfare <- welfare %>% 
                  filter(!is.na(jobcode)) %>% 
                  filter(!is.na(month.wage))


plot(x=welfare$jobcode, y=welfare$month.wage)
boxplot(welfare$month.wage~welfare$jobcode, data=welfare)
# 한국표준직업분류6차 체계로 나눴을 때 평균 임금 데이터를 찾아
# 적용해보려고 했으나, 해당 그래프 내용을 통해 
# 부적절함을 깨달음


###################### 참고사항 ############################
# 한국표준직업분류6차 체계로 나눴을 때의 평균값

avg_wage$mean.cut <- cut(avg_wage$jobcode,
    breaks = c(0,100,200,300,400,500,600,700,800,900,1000,1100),
    right = F)

avg_wage %>% 
  group_by(mean.cut) %>% 
  summarise(mean(`mean(month.wage)`))
#    mean.cut           `mean(\`mean(month.wage)\`)`
# *  <fct>                                  <dbl>
# 1  [100,200)                               456.
# 2  [200,300)                               351.
# 3  [300,400)                               273.
# 4  [400,500)                               195.
# 5  [500,600)                               237.
# 6  [600,700)                               178.
# 7  [700,800)                               295.
# 8  [800,900)                               308.
# 9  [900,1e+03)                             137.
# 10 [1e+03,1.1e+03)                         408.

###########################################################

avg_wage <- welfare %>% 
  filter(!is.na(jobcode)) %>% 
  filter(!is.na(month.wage)) %>% 
  group_by(jobcode) %>% 
  summarise(mean(month.wage))
avg_wage


# jobcode 데이터는 있으나 month.wage는 결측값인 경우

sum(!is.na(welfare$jobcode) & is.na(welfare$month.wage))  #2892

no.na.jobcode <- avg_wage$jobcode
length(no.na.jobcode) #142

for(i in 1:length(no.na.jobcode)){
  welfare$month.wage <- ifelse(no.na.jobcode[i] == welfare$jobcode & is.na(welfare$month.wage), 
                               avg_wage$`mean(month.wage)`[i],
                               welfare$month.wage)
}

sum(!is.na(welfare$jobcode) & is.na(welfare$month.wage)) #27


# month.wage 데이터는 있으나 jobcode는 결측값인 경우

sum(!is.na(welfare$month.wage) & is.na(welfare$jobcode))  #0


sum(is.na(welfare$month.wage) | is.na(welfare$jobcode))  #7927
# 위 과정을 진행하고도 결측값인 경우는 분석진행할 때 제외하고 분석한다


# num형 데이터 -> chr 형태로 변경(그래프에서 보기 쉽도록)

welfare$gender <- sapply(welfare$gender, switch, "1" = "남", "2" = "여")
welfare$religion <- sapply(welfare$religion, switch, "1" = "있음", "2" = "없음")

# month.wage에 결측값있는 경우를 제외한 데이터
# 결측값 아예 존재하지 않는 데이터와 동일

# 결측값 존재하지 않는 데이터
job_wage_welfare <- welfare %>% 
  filter(!is.na(month.wage) & !is.na(jobcode))
sum(is.na(job_wage_welfare$month.wage))  #0
sum(is.na(job_wage_welfare$jobcode))  #0

# jobcode에 결측값 있는 경우 제외한 데이터(month.wage는 결측값 있을 수 있음)
jobcode_welfare <- welfare %>% 
  filter(!is.na(jobcode))
sum(is.na(jobcode_welfare$month.wage))  #27
sum(is.na(jobcode_welfare$jobcode))  #0



# jobcode와 xlsx 파일 내용을 기반으로 파생변수 job 생성

raw_jobcode <- read_excel("Koweps_Codebook.xlsx", sheet = 2)
str(raw_jobcode)

for(i in 1:nrow(raw_jobcode)){
  job_wage_welfare$job <- ifelse(raw_jobcode$code_job[i]==job_wage_welfare$jobcode, 
                                 raw_jobcode$job[i],
                                 job_wage_welfare$job)
}

sum(job_wage_welfare$job=="NULL")  #0, 정상적으로 잘 진행되었다


write.csv(job_wage_welfare, "job_wage_welfare.csv", row.names = FALSE)

for(i in 1:nrow(raw_jobcode)){
  jobcode_welfare$job <- ifelse(raw_jobcode$code_job[i]==jobcode_welfare$jobcode,
                                raw_jobcode$job[i],
                                jobcode_welfare$job)
}

sum(jobcode_welfare$job=="NULL") #0, 정상적으로 잘 진행되었다

write.csv(jobcode_welfare, "jobcode_welfare.csv", row.names = FALSE)

# 3. 분석
# 월급을 기준으로 비교하므로 month.wage에 대한 결측값이 없도록 만든
# job_wage_welfare 데이터 사용할 것이다

plot(density(job_wage_welfare$month.wage),
     main = "평균 월급의 밀도",
     xlab = "평균 월급(만원)",
     xlim = c(0,2000))

# 성별에 따라 월급이 다를까?

w_gender <- tapply(job_wage_welfare$month.wage, job_wage_welfare$gender, 
                   FUN = function(x){round(mean(x),1)})
w_gender
str(w_gender)

w_gender_bar <- barplot(w_gender,col = c("seagreen3","skyblue"),
        ylim=c(0,300),
        main = "성별에 따른 평균 월급",
        xlab = "성별",
        ylab = "평균 월급(만원)")
text(w_gender_bar, w_gender, 
     labels=w_gender, pos=3) 


# -성별에 따른 월급 차이 분석

# 결과적으로 여자보다 남자의 평균 월급이 111만원 더 높았다
# 이 결과를 가지고 한 가지 의문이 들었다.
# 성별에 따라 선호 직업이 다른 것이 월급에 영향을 미치지 않았을까?
# 이에 대한 분석을 추가로 진행했다.


# -몇 살 때 월급을 가장 많이 받을까?

plot(job_wage_welfare$month.wage~job_wage_welfare$age)
# 극단값이 있음을 확인할 수 있음
# 따라서 연령별 평균으로 바로 따지는 것이 아니라
# 중위값과 평균을 구해 두 수의 평균을 나이별 평균월급으로 볼 것이다

w_age <- tapply(job_wage_welfare$month.wage,
                job_wage_welfare$age,
                FUN = function(x){round((mean(x)+median(x))/2, 1)})

max(w_age) #최대 평균 월급 : 287
names(w_age[w_age==max(w_age)]) #46세


# -나이에 따른 월급 평균표 만들기

barplot(w_age, col="skyblue",
        main = "나이에 따른 평균 월급",
        xlab = "나이",
        ylab = "평균 월급(만원)",
        ylim = c(0,310))



# -어떤 연령대의 월급이 가장 많을까?

plot(job_wage_welfare$month.wage~job_wage_welfare$age.cut)
# 이 때도 마찬가지로 극단값 존재
# (중위값 + 평균값)/2 를 연령대별 평균월급으로 넣을 것이다

table(job_wage_welfare$age.cut)
# [10,20)  [20,30)  [30,40)  [40,50)  [50,60)  [60,70)  [70,80) [80,100) 
# 0        123      796      1523     1710     1460     1034      853 

w_age.cut <- tapply(job_wage_welfare$month.wage,
                job_wage_welfare$age.cut,
                FUN = function(x){round((mean(x)+median(x))/2, 1)})

w_age.cut
# [10,20)  [20,30)  [30,40)  [40,50)  [50,60)  [60,70)  [70,80) [80,100) 
# NA       126.7    190.7    260.6    243.4    188.3    108.9     93.1 

max(w_age.cut, na.rm = T) #최대 평균 월급 : 260.6
names(w_age.cut[w_age.cut==max(w_age.cut, na.rm = T)]) #[40,50), 40대



# -연령대별 월급 평균표 만들기

w_age.cut_bar <- barplot(w_age.cut[-1], col="skyblue",
        main = "연령대에 따른 평균 월급",
        xlab = "연령대",
        ylab = "평균 월급(만원)",
        ylim = c(0,310),
        names = c("20대","30대","40대","50대","60대","70대","80 이상")
        )
text(w_age.cut_bar, w_age.cut[-1], 
     labels=w_age.cut[-1], 
     pos=3, cex = 0.7) 



# -성별 월급 차이는 연령대별로 다를까?

w_m_age.cut <- job_wage_welfare %>%
  filter(gender=="남") %>%
  group_by(age.cut) %>%
  summarise(round((mean(month.wage)+median(month.wage))/2,1))

w_f_age.cut <- job_wage_welfare %>%
  filter(gender=="여") %>%
  group_by(age.cut) %>%
  summarise(round((mean(month.wage)+median(month.wage))/2,1))

w_g_age.cut <- data.frame(age.cut=as.vector(w_m_age.cut[[1]]),
                          male=w_m_age.cut[[2]],
                          female=w_f_age.cut[[2]],
                          diff=round((w_g_age.cut$male-w_g_age.cut$female),1))
w_g_age.cut

w_g_age.cut_bar <- barplot(as.matrix(w_g_age.cut[2:4])~w_g_age.cut$age.cut,
                           col = c("seagreen3","skyblue","salmon2"),
                           beside = T,
                           main = "성별에 따른 연령대별 평균 월급",
                           xlab = "연령대",
                           ylab = "평균 월급(만원)",
                           ylim = c(0,370),
                           names = c("20대","30대","40대","50대","60대","70대","80 이상")
                           )
text(w_g_age.cut_bar, t(as.matrix(w_g_age.cut[2:4])), 
     labels=t(as.matrix(w_g_age.cut[2:4])), 
     pos=3, cex = 0.5)
legend("topright",
       legend=c("남","여","차이"),
       fill=c("seagreen3","skyblue","salmon2"))

# 이를 통해 20대에는 거의 동일하던 남녀의 평균 월급이 50대가 되어감에 따라
# 점점 더 큰 차이를 보이고 있음을 알 수 있다
# 또한 60대부터는 다시 차이가 줄어듬을 볼 수 있다
# 가장 차이가 많이 나는 것은 50대로 145.4만원의 차이가 발생했다.



# -종교와 월급이 관계가 있을까?

str(job_wage_welfare)
w_religion <- with(job_wage_welfare,
                   tapply(month.wage, religion, 
                          FUN = function(x){round((mean(x)+median(x))/2,1)})
)

w_religion


w_religion_bar <- barplot(w_religion, col=c("skyblue2","yellowgreen"),
                         main = "종교 유무에 따른 평균 월급",
                         xlab = "종교 유무",
                         ylab = "평균 월급(만원)",
                         ylim = c(0,210),
                         )
text(w_religion_bar, w_religion, 
     labels=w_religion, 
     pos=3, cex = 0.7) 


# 분석 결과 종교 유무와 평균 월급은 무관했다.
# 종교가 없는 경우의 평균 월급이 17만원 더 많았으나
# 유의미하다고 보기는 어려운 차이였다.



#   -혼인여부와 월급 관계가 있을까?

str(job_wage_welfare)
w_marriage <- with(job_wage_welfare,
                   tapply(month.wage, marriage, 
                          FUN = function(x){round((mean(x)+median(x))/2,1)})
)

w_marriage


w_marriage_bar <- barplot(w_marriage, col=terrain.colors(7),
                          main = "혼인 여부에 따른 평균 월급",
                          xlab = "혼인 여부",
                          ylab = "평균 월급(만원)",
                          ylim = c(0,220),
                          names = c("비해당","유배우","사별","이혼",
                                    "별거","미혼","기타")
)
text(w_marriage_bar, w_marriage, 
     labels=w_marriage, 
     pos=3, cex = 0.7) 



# -권역별 월급 차이가 있을까?

str(job_wage_welfare)
w_area <- with(job_wage_welfare,
                   tapply(month.wage, area, 
                          FUN = function(x){round((mean(x)+median(x))/2,1)})
)

w_area

max(w_area)-min(w_area)

w_area_bar <- barplot(w_area, col=cm.colors(7),
                          main = "권역별 평균 월급",
                          xlab = "권역",
                          ylab = "평균 월급(만원)",
                          ylim = c(0,250),
                          names = c("서울","인천/경기",
                                    "부산/경남/울산","대구/경북",
                                    "대전/충남","강원/충북",
                                    "광주/전남/전북/제주도")
)
text(w_area_bar, w_area, 
     labels=w_area, 
     pos=3, cex = 0.7) 


# -어떤 직업이 월급을 가장 많이 받을까?

str(job_wage_welfare)
w_job <- with(job_wage_welfare,
               tapply(month.wage, jobcode, 
                      FUN = function(x){round((mean(x)+median(x))/2,1)})
)

w_job


w_job_bar <- barplot(w_job, col = cm.colors(142),
                      main = "직종별 평균 월급",
                      xlab = "직종",
                      ylab = "평균 월급(만원)",
                      ylim = c(0,1000))

dev.off()
w_job <- with(job_wage_welfare,
              tapply(month.wage, job, 
                     FUN = function(x){round((mean(x)+median(x))/2,1)})
)

w_job

max(w_job)  #843.6만원
names(w_job[max(w_job)==w_job]) #의료진료 전문가(코드번호 241)

## 추가 : 가장 낮은 평균 월급 받는 직업은?

min(w_job)  #80.2만원
names(w_job[min(w_job)==w_job])  #가사 및 육아 도우미

## 추가 : 가장 높은 평균 월급을 받는 직업 5개는?

head(sort(w_job, decreasing = T), 5)

## 추가 : 가장 낮은 평균 월급을 받는 직업 10개는?

head(sort(w_job), 5)

## 추가 : 최저 평균 월급과 최고 평균 월급의 차이는?

max(w_job)-min(w_job) #763.4만원



# 6. 분석
# 이후 내용에서는 평균 월급에 대한 내용이 없으므로 
# 최대한 많은 자료를 이용하기 위해 jobcode_welfare 자료를 사용한다
# (위 전처리 과정에서 만들었던 jobcode_welfare는 
# jobcode에 대한 결측값은 없으나 month.wage에 대한 결측값은 존재했다.)

# -성별로 어떤 직업이 가장 많을까?

# 남성
str(jobcode_welfare)

j_gender_m <- jobcode_welfare %>% 
  filter(gender=="남") %>% 
  group_by(job) %>% 
  summarise(n())

str(j_gender_m)

# 남성의 직업 중 가장 높은 빈도수를 보인 직종?

nrow(j_gender_m)  #141개의 직업에 종사
j_gender_m$job[max(j_gender_m$`n()`)==j_gender_m$`n()`]  #작물재배 종사자
max(j_gender_m$`n()`)  #639

# 남성의 높은 빈도수를 보인 상위 5개 직종

head(j_gender_m[order(j_gender_m$`n()`, decreasing = T),],5)
#     job             `n()`
#    <chr>            <int>
# 1 작물재배 종사자    639
# 2 자동차 운전원      251
# 3 경영관련 사무원    213
# 4 영업 종사자        141
# 5 매장 판매 종사자   132


# 여성
j_gender_f <- jobcode_welfare %>% 
  filter(gender=="여") %>% 
  group_by(job) %>% 
  summarise(n())

str(j_gender_f)

# 여성의 직업 중 가장 높은 빈도수를 보인 직종?

nrow(j_gender_f)  #104개의 직업에 종사
j_gender_f$job[max(j_gender_f$`n()`)==j_gender_f$`n()`]  #작물재배 종사자
max(j_gender_f$`n()`)  #679명

# 여성의 높은 빈도수를 보인 상위 5개 직종

head(j_gender_f[order(j_gender_f$`n()`, decreasing = T),],5)
#     job                  `n()`
#    <chr>                 <int>
# 1 작물재배 종사자         679
# 2 청소원 및 환경 미화원   228
# 3 매장 판매 종사자        221
# 4 제조관련 단순 종사원    185
# 5 회계 및 경리 사무원     176


opar <- par(mfrow=c(1,2))

j_gender_m <- jobcode_welfare %>% 
  filter(gender=="남") %>% 
  group_by(jobcode) %>% 
  summarise(n())

barplot(j_gender_m$`n()`~j_gender_m$jobcode, col = rainbow(139),
        main = "남성 직업별 인원수",
        xlab = "직종",
        ylab = "인원수",
        ylim = c(0,250))

j_gender_f <- jobcode_welfare %>% 
  filter(gender=="여") %>% 
  group_by(jobcode) %>% 
  summarise(n())

barplot(j_gender_f$`n()`~j_gender_f$jobcode, col = rainbow(101),
        main = "여성 직업별 인원수",
        xlab = "직종",
        ylab = "인원수",
        ylim = c(0,250))

dev.off()

# -종교가 있는 사람들이 이혼을 덜 할까

str(jobcode_welfare)
m_religion <- jobcode_welfare %>% 
  filter(marriage==3) %>% 
  group_by(religion) %>% 
  summarise(n()) %>% 
  as.data.frame()

m_religion

m_religion_bar <- barplot(m_religion$`n()`~m_religion$religion, col=cm.colors(2),
                      main = "종교의 유무에 따른 이혼자 수",
                      xlab = "종교 유무",
                      ylab = "이혼자 수(명)",
                      ylim = c(0,280)
)

text(m_religion_bar, t(m_religion$`n()`), 
     labels=t(m_religion$`n()`), 
     pos=3, cex = 0.8) 


# -종교 유무에 따른 이혼율 분석하기

# 종교 유
m_religion_y <- jobcode_welfare %>%
  filter(!marriage %in% c(0,5) & religion=="있음") %>%  #비해당 및 미혼 제외
  group_by(marriage) %>% 
  summarise(n()) %>% 
  as.data.frame()
m_religion_y

# 종교 있을 때 이혼율

round(m_religion_y$`n()`[m_religion_y$marriage==3] * 100/sum(m_religion_y), 2)
# 5.58


# 종교 무
m_religion_n <- jobcode_welfare %>% 
  filter(!marriage %in% c(0,5) & religion=="없음") %>% 
  group_by(marriage) %>% 
  summarise(n()) %>% 
  as.data.frame()
m_religion_n

# 종교 없을 때 이혼율

round(m_religion_n$`n()`[m_religion_n$marriage==3] * 100/sum(m_religion_n), 2)
# 7.6




# -연령대 및 종교 유무에 따른 이혼율 분석하기

str(jobcode_welfare)

# 종교 유
age_rel_y <- jobcode_welfare[jobcode_welfare$religion=="있음" & !jobcode_welfare$marriage %in% c(0,5),
                             c(3,9)]
age_rel_y <- as.matrix(table(age_rel_y))
age_rel_y <- rbind(age_rel_y, total=apply(age_rel_y, 2, sum))
age_rel_y <- rbind(age_rel_y[,-1], per=round(age_rel_y[3,-1]*100/age_rel_y[6,-1], 2))
age_rel_y

# 종교 무
age_rel_n <- jobcode_welfare[jobcode_welfare$religion=="없음" & !jobcode_welfare$marriage %in% c(0,5),
                             c(3,9)]

age_rel_n <- as.matrix(table(age_rel_n))
age_rel_n <- rbind(age_rel_n, total=apply(age_rel_n, 2, sum))
age_rel_n <- rbind(age_rel_n[,-1], per=round(age_rel_n[3,-1]*100/age_rel_n[5,-1], 2))
age_rel_n

diff <- as.vector(abs(age_rel_y[7,]-age_rel_n[6,]))
diff

# -연령대 및 종교 유무에 따른 이혼율 표 만들기

res <- t(rbind(age_rel_y[7,],age_rel_n[6,], diff))
res

mper_age_rel_bar <- barplot(res~colnames(age_rel_n),
                           col = c("seagreen3","skyblue","salmon2"),
                           beside = T,
                           main = "종교 유무에 따른 연령대별 이혼율",
                           xlab = "연령대",
                           ylab = "이혼율(%)",
                           ylim = c(0,15),
                           names = c("20대","30대","40대","50대","60대","70대","80 이상")
)
text(mper_age_rel_bar, t(res), 
     labels=t(res), 
     pos=3, cex = 0.6)
legend("topright",
       legend=c("유","무","차이"),
       fill=c("seagreen3","skyblue","salmon2"))



# -노년(유년)층이 많은 지역은 어디일까?
# 문제는 직업에 대한 것을 중점으로 데이터 처리를 진행하다보니
# 전처리 과정에서 16세 이하, 100세 이상에 해당되는 경우는 데이터를 삭제 시켰었다
# 따라서 해당 분석을 진행하기 위해 raw_welfare로부터 다시 가져와
# 전처리 과정을 거쳤다

raw_welfare <- read.spss(file = "Koweps_hpc10_2015_beta1.sav",
                         to.data.frame = T)

# 필요한 자료만 넣은 복사본 만들기(태어난 해와 지역 열만 가져온다)

welfare <- raw_welfare[c("h10_g4","h10_reg7")]
str(welfare)

# 변수명 변경

colnames(welfare) <- c("birth.year","area")
str(welfare)

welfare$age <- 2021 - welfare$birth.year + 1
str(welfare)

# 노년층(은퇴 연령인 60세 이상을 노년으로 설정하고 진행)

a_old <- welfare %>% 
  filter(age>=60) %>% 
  group_by(area) %>% 
  summarise(n())
a_old

# 유년층(학생 신분인 19까지를 유년으로 설정하고 진행)

a_young <- welfare %>% 
  filter(age<=19) %>% 
  group_by(area) %>% 
  summarise(n())
a_young


# -지역별 연령대 비율표 만들기

# 1) 권역별 노년/유년층 수(막대그래프)
res <- cbind(a_old$`n()`,a_young$`n()`)
res

area_age_bar <- barplot(res~a_old$area,
                            col = c("seagreen3","salmon2"),
                            beside = T,
                            main = "권역별 노년/유년층 수",
                            xlab = "권역",
                            ylab = "인구수(명)",
                            ylim = c(0,2000),
                            names = c("서울","인천/경기",
                                      "부산/경남/울산","대구/경북",
                                      "대전/충남","강원/충북",
                                      "광주/전남/전북/제주도")
)
text(area_age_bar, t(res), 
     labels=t(res), 
     pos=3, cex = 0.6)
legend("topright",
       legend=c("노년층","유년층"),
       fill=c("seagreen3","salmon2"),
       cex = 0.8)


# 노년층 및 유년층의 권역별 분포(파이그래프)

res_per <- prop.table(res, 2)
res_per

opar <- par(mfrow=c(1,2))

pie(res_per[,1],
    labels = paste(c("서울","인천/경기","부산/경남/울산","대구/경북",
                     "대전/충남","강원/충북","광주/전남/전북/제주도"),
                   round(res_per[,1]*100,2), "%"),
    col = cm.colors(7),
    cex = 0.8,
    main = "권역별 노년층 분포 비율")
pie(res_per[,2],
    labels = paste(c("서울","인천/경기","부산/경남/울산","대구/경북",
                     "대전/충남","강원/충북","광주/전남/전북/제주도"),
                   round(res_per[,2]*100,2), "%"),
    col = cm.colors(7),
    cex = 0.8,
    main = "권역별 유년층 분포 비율")

dev.off()


# 7. kmeans 유사그룹 생성(job_wage_welfare 데이터를 기준으로 진행)
# -그룹 특성 분석
# -클러스터 생성
# -기준 예시 :  월급, 연령대,...=>그룹 특성 이해

str(job_wage_welfare)

kmean_data <- job_wage_welfare[,c(1,3:8)]

# 직업의 경우 직업코드로 진행하면 원핫인코딩 진행시 너무 복잡해짐
# 따라서 한국표준직업분류6차 체계로 나누어 진행하고자 한다.
# 직업코드를 기준으로 한국표준직업분류 6차 체계로 나누기

# 직업코드     한국표준직업분류
# 100번대       관리자 직군
# 200번대       전문가 직군
# 300번대       사무원 직군
# 400번대       서비스 직군
# 500번대       판매 직군
# 600번대       농/어/축산 직군
# 700번대       기능사 직군
# 800번대       기계조작원 직군
# 900번대       단순종사원 직군
# 1000번대      군 종사자 직군

kmean_data$jobcode <- with(kmean_data, ifelse(jobcode<200, 100,
                        ifelse(jobcode<300, 200,
                               ifelse(jobcode<400, 300,
                                      ifelse(jobcode<500, 400,
                                             ifelse(jobcode<600, 500,
                                                    ifelse(jobcode<700, 600,
                                                           ifelse(jobcode<800, 700,
                                                                  ifelse(jobcode<900, 800,
                                                                         ifelse(jobcode<1000, 900, 1000))))))))))

kmean_data$gender <- sapply(kmean_data$gender, switch, "남"=1, "여"=2)
kmean_data$religion <- sapply(kmean_data$religion, switch, "있음"=1, "없음"=2)

str(kmean_data)

# gender, marriage, religion, jobcode, area에 대해 원핫인코딩 진행

old.colname <- colnames(kmean_data[,-c(5,7)]) 
old.colname
for(i in old.colname){
  level <- unique(kmean_data[[i]])
  for(j in level){
    new <- paste(i, j, sep = ".")
    kmean_data[new] <- ifelse(kmean_data[i]==j,1,0)
  }
}
colnames(kmean_data)
colnames(kmean_data[,-c(1:4,6)])

# 표준화

kmean_data_z <- as.data.frame(lapply(kmean_data[,-c(1:4,6)], scale))
head(kmean_data_z,3)

# elbow 포인트 찾기

visual <- NULL
for(i in 2:15) {
  set.seed(0312)
  result <- kmeans(kmean_data_z, i)
  visual[i] <- result$tot.withinss
}
plot(visual[-1], type="l", ylab="", xlab="", main="cluster의 개수에 따른 내부분산")
abline(v=12,col="red")

# 군집화

set.seed(0312)
welfare_clusters <- kmeans(kmean_data_z,12)
welfare_clusters

